"""Validación numérica de los diseños y de su implementación causal."""
import unittest
import numpy as np
from scipy import signal
from filtros_digitales import FS, TONES, CASES, design, apply, response

class FilterTests(unittest.TestCase):
    def test_known_tone_gain_matches_frequency_response(self):
        # Medir amplitudes por mínimos cuadrados evita confundir fase con atenuación.
        t=np.arange(FS*3)/FS
        for kind in CASES:
            for family,size in [('FIR',201),('IIR',4)]:
                coeff=design(kind,family,size)
                for f in TONES:
                    with self.subTest(tipo=kind,familia=family,frecuencia=f):
                        x=np.sin(2*np.pi*f*t); y=apply(coeff,family,x)
                        keep=t>=.5
                        basis=np.column_stack([np.sin(2*np.pi*f*t[keep]),np.cos(2*np.pi*f*t[keep])])
                        amp=np.linalg.norm(np.linalg.lstsq(basis,y[keep],rcond=None)[0])
                        expected=abs(response(coeff,family,np.array([f]))[0])
                        self.assertAlmostEqual(amp,expected,places=8)
    def test_fir_has_symmetric_impulse_and_expected_delay(self):
        for kind in CASES:
            for taps in [51,101,201]:
                b=design(kind,'FIR',taps)
                np.testing.assert_allclose(b,b[::-1],atol=1e-14)
                self.assertEqual(int(np.argmax(abs(b))), (taps-1)//2)
    def test_all_iir_configurations_are_stable(self):
        for kind in CASES:
            for order in [2,4,6]:
                _,p,_=signal.sos2zpk(design(kind,'IIR',order))
                self.assertTrue(np.all(abs(p)<1))
    def test_cutoff_conventions(self):
        # Butterworth usa media potencia. FIR con ventana usa media amplitud.
        for kind in CASES:
            cutoff=np.atleast_1d(CASES[kind]['cutoff'])
            self.assertTrue(np.allclose(abs(response(design(kind,'IIR',4),'IIR',cutoff)),2**-.5,atol=1e-10))
            self.assertTrue(np.allclose(abs(response(design(kind,'FIR',201),'FIR',cutoff)),.5,atol=.01))

if __name__=='__main__': unittest.main(verbosity=2)
