# Publicación manual en GitHub

El repositorio de destino es:
https://github.com/lcarmona2901-lgtm/filtros-digitales-python

El proyecto no se publicó automáticamente. La conexión rechazó la escritura y se eligió la entrega del ZIP para subirlo manualmente.

## Opción con Git

1. Descomprimir el ZIP.
2. Abrir una terminal en la carpeta que contiene `filtros_digitales.py` y `README.md`.
3. Ejecutar los comandos siguientes. Suponen que el repositorio remoto sigue vacío:

```bash
git init -b main
git add .
git commit -m "Implementar y evaluar filtros digitales FIR e IIR en Python"
git remote add origin https://github.com/lcarmona2901-lgtm/filtros-digitales-python.git
git push -u origin main
```

Git puede solicitar la identidad de autor para el primer commit. Configurar nombre y correo en este repositorio con los valores que se deseen usar, si aún no existen. La autenticación de GitHub debe realizarla el titular de la cuenta.

Si el repositorio remoto ya tiene contenido, clónalo primero y copia los archivos del proyecto dentro de la carpeta clonada. Después ejecuta `git add .`, `git commit` y `git push`. No es necesario forzar la subida.

## Alternativa en la web

Abrir el repositorio en GitHub, usar la opción de subir archivos y confirmar los cambios. Cargar los archivos descomprimidos para que el código pueda consultarse directamente, en lugar de subir únicamente el ZIP.

## Comprobación final

En el repositorio deben verse `README.md`, `filtros_digitales.py`, `test_filtros.py`, `requirements.txt`, el informe, la presentación y la carpeta `resultados`.
